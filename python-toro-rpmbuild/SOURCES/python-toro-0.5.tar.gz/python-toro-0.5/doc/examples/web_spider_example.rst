:class:`~toro.Queue` and :class:`~toro.Semaphore` example - a parallel web spider
=================================================================================

.. automodule:: examples.web_spider_example

.. literalinclude:: ../../examples/web_spider_example.py
    :start-after: # start-file
